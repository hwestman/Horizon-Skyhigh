arguments=2

if [[ $# -lt $arguments ]]; then echo -e "usage: [stop/start/restart] [machines]\n"; exit 0; fi

serv="api network compute cert"
action=$1
shift;
for i in "$@"
 do
  for x in $serv
   do
    ssh root@$i "$action nova-$x"
   done
 done
