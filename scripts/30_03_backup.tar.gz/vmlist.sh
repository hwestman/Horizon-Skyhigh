nova-manage vm list | awk '{ print $1 " " $2 " " $8 }'
