watch -n 1 nova list
