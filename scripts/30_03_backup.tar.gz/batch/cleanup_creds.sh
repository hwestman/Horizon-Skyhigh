#!/bin/bash
rm -rf /root/login_details/$1
